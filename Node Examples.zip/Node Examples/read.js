var fs=require("fs");
var data="";
//create a readable stream
var readstream=fs.createReadStream("input.txt");
readstream.setEncoding("UTF8");

//handle the events-read,end and error
readstream.on('data',function(stream){
data+=stream;
});
readstream.on('end',function(){
    console.log(data);
});
readstream.on('error',function(err){
    console.log(err.stack);
});
console.log('program ended');