var events=require("events");
var eventemitter=new events.EventEmitter();
var eventhandler=function(){
    var fname="Tom";
    var lname="jerry";
    console.log("FullName:"+(fname+""+lname));
}
eventemitter.on("printname",eventhandler);
eventemitter.emit("printname");
