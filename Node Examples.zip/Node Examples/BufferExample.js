var buff=new Buffer('ABC');
var buffanother=new Buffer(3);
buff.copy(buffanother);
console.log("Buffer  Content:"+buff.toString());
console.log("Buffer  Content copied:"+buffanother.toString());