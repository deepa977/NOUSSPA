var fs=require('fs');
var data="How can a calm cram in a clean cream can?";

var writestream=fs.createWriteStream('output.txt');
writestream.write(data,'UTF8');
writestream.end();


writestream.on('finish',function(){
console.log('write completed');
});
writestream.on('error',function(){
console.log(err.stack);
});
console.log('program ended');