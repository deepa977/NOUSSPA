console.log("My first Node Example.....");
function PrintHello()
{
    console.log("printing hello.....");
}
var t=setInterval(PrintHello,5000);
clearInterval(t);
console.log(__filename);

console.log(__dirname);
