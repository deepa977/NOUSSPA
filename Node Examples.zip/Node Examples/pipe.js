var fs=require('fs');
var readstream=fs.createReadStream('output.txt');
var writestream=fs.createWriteStream('newoutput.txt');
readstream.pipe(writestream);
console.log("program ended");