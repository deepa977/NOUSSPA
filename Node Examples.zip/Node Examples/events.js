var events=require("events");
var eventemitter=new events.EventEmitter();

//create an event handler
var eventhandler=function(){
    console.log("I hear a scream.....");
}

//assign the event handler to an event
eventemitter.on("scream",eventhandler);
eventemitter.emit("scream");