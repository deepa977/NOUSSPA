//import the required modules
var http=require("http");

//create a server to accept request and response
http.createServer(function(request,response)
{
    response.writeHead(200,{'Content-Type':'text/plain'});
    response.end("Hello World...\n");
}).listen(8081);
console.log("server running on localhost:8081....");
